import './register.css';
import 'react-notifications/lib/notifications.css';
import React, { useEffect, useState } from 'react';
import {NotificationContainer, NotificationManager} from 'react-notifications';
import axios from 'axios';
import { useHistory } from "react-router-dom";

export const Register = () => {
    let [formData, setFormData] = useState({})
    let history = useHistory();
    const handleClick = (arg) => {
        history.push(`/${arg}`)
    }
    const handleChange = (e) => {
        // e.preventDefault();
        e.persist();
        console.log(e.target.value,'e')
        console.log(e.target.name, 'name')
        setFormData(prevState => ({
            ...prevState,
            [e.target.name] : e.target.value
        }))
        // console.log(formData, 'formData in change')
    }
    const handleSubmit = () => {
        console.log(formData, 'formData')
        if (!formData.name) {
            return NotificationManager.error('Please enter a name');
        }
        if (!formData.email) {
            return NotificationManager.error('Please enter a email');
        }
        if (!formData.password) {
            return NotificationManager.error('Please enter a password');
        }
        axios.post('http://localhost:8000/user/create', formData).then(
            user => {
                console.log(user, 'user')
                NotificationManager.success('Registered Successfully');
                setTimeout(() => {
                    history.push('/login')
                }, 2000)
            },
            err => {
                console.log(err, 'err')
            }
        )
        // setTimeout(() => {
        //     history.push('/home')
        // }, 1000)
    }
    return (
        <div className="register">
            <NotificationContainer/>
            <h4 className="registerTitle">Register</h4>
            <div className="registerForm">
                <label>Name</label>
                <input name="name" className="registerInput" placeholder="Enter a name..." onChange={handleChange} />
                <label>Email</label>
                <input name="email" className="registerInput" placeholder="Enter a email..." onChange={handleChange} />
                <label>Password</label>
                <input name="password" className="registerInput" placeholder="Enter a password..." onChange={handleChange} />
                <button className="registerButton" onClick={() => handleSubmit() }>Submit</button>
            </div>
            <button className="registerLoginButton" onClick={() => handleClick('login')}>Login</button>
        </div>
    )
}