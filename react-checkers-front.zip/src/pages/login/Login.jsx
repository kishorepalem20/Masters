import './login.css';
import 'react-notifications/lib/notifications.css';
import React, { useState, useEffect } from 'react';
import {NotificationContainer, NotificationManager} from 'react-notifications';
import { useHistory } from "react-router-dom";
import axios from 'axios';

export const Login = () => {
    let history = useHistory();
    let [formData, setFormData] = useState([])
    const handleClick = (arg) => {
        history.push(`/${arg}`)
    }
    const handleChange = (e) => {
        e.persist();
        console.log(e.target.name, 'name')
        console.log(e.target.value, 'value')
        setFormData(prevState => ({
            ...prevState,
            [e.target.name] : e.target.value
        }
        ))
    }
    const handleSubmit = () => {
        if (!formData.email) {
            return NotificationManager.error('Please enter a email');
        }
        if (!formData.password) {
            return NotificationManager.error('Please enter a password');
        }
        axios.post('http://localhost:8000/user/login', formData).then(
            user => {
                console.log(user, 'user')
                localStorage.setItem('token', user.data.token)
                NotificationManager.success('Login Success');
                setTimeout(() => {
                    history.push('/game')
                }, 2000)
            },
            err => {
                console.log(err, 'err')
                NotificationManager.error('Login Failed', 'Please check your credentials')
            }
        )
    }
    return (
            <div className="login">
                <NotificationContainer/>
                <h4 className="loginTitle">Login</h4>
                <div className="loginForm">
                    <label>Email</label>
                    <input className="loginInput" name="email" type="text" placeholder="Enter your email" onChange={handleChange} />
                    <label>Password</label>
                    <input className="loginInput" name="password" type="password" placeholder="Enter your password" onChange={handleChange} />
                    <button className="loginButton" onClick={handleSubmit}>Submit</button>
                </div>
                <button className="loginRegisterButton" onClick={() => handleClick('register')}>Register</button>
            </div>
    )
}