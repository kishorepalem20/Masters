// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './topbar.css';
import { useHistory } from "react-router-dom";
import { Link } from 'react-router-dom';
// import { faLongArrowAltUp } from '@fortawesome/free-solid-svg-icons';
// import { useDispatch, useSelector } from 'react-redux';
import React ,{  useEffect, useState } from 'react';
// import { getUserDetail } from '../../redux/actions/getUserDetail';
import axios from 'axios';

export default function TopBar() {
    let history = useHistory();
    // let dispatch = useDispatch();
    // let getUserDetailReducerState = useSelector(state => state.getUserDetailReducer.payload)
    let [userDetail, setUserDetail] = useState({});
    let [loading, setLoading] = useState(true);
    const handleClick = (arg) => {
        console.log(arg, 'argments')
        history.push(`/${arg}`);
    }
    const logout = () => {
        localStorage.removeItem('token')
        history.push('/login')
    }
    useEffect(() => {
        console.log(userDetail, 'userDetail')
        let config = {
            headers: {'Authorization': `${localStorage.getItem('token')}`},
        }
        return axios.get('http://localhost:8000/user/getUserDetail', config).then(
            user => {
                console.log(user, 'user in getUserDetailAction')
                setUserDetail(user.data)
                setLoading(false);
            },
            err => console.log(err)
        )
            
    }, [])
    return (
        <div className="top">
            <div className="topLeft">
                {/* <FontAwesomeIcon icon="fa-brands fa-facebook-f" /> */}
            <i class="topIcon fa-brands fa-facebook-f"></i>
            <i class="topIcon fa-brands fa-twitter"></i>
            <i class="topIcon fa-brands fa-pinterest"></i>
            <i class="topIcon fa-brands fa-instagram"></i>
            </div>
            <div className="topCenter">
            <ul className="topList">
                    { (localStorage.getItem('token')) ? (
                            <li className="topListItem" style={{color: 'red'}} onClick={() => logout()}>LOGOUT</li>
                    ) : ''}
                </ul>
            </div>
            <div className="topRight">
                {
                    (!loading) ? (
                        <div>
                        { (userDetail) ? (
                            <p className="hiName">Hi {userDetail.name}</p>
                        ) : ''}
                        {/* <img
                    className="topImg"
                    src="https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg"
                    alt=""
                /> */}
                </div>
                    ) : (
                        ''
                    )
                }
            </div>
        </div>
    )
}