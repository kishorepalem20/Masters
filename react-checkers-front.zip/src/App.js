import React from 'react';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
import { Login } from "./pages/login/Login";
import { Game } from './Game';
import { Register } from './pages/register/Register';
import TopBar from './pages/topbar/TopBar';
import PublicRoute from './routes/publicRoute';
import PrivateRoute from './routes/privateRoute';

  export const App = () => {

    return (
            <Router>
                <Switch>
                    {/* <Route path="/login">
                        <Login />
                    </Route> */}
                    {/* <Route path="/game">
                        <TopBar />
                        <Game />
                    </Route> */}
                    <PrivateRoute path="/game" component={Game} />
                    <PublicRoute path="/register" component={Register} />
           <PublicRoute path="/login" restricted={true} component={Login} exact/>
                </Switch>
            </Router>
    )
  }

  export default App;