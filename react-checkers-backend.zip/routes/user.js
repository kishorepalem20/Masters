const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken')

const User = require('../models/userModel');


function verifyToken(req, res, next) {
    console.log(req.headers.authorization)
    if (!req.headers.authorization) {
        return res.status(401).send('Unauthorized request')
    }
    let token = req.headers.authorization
    if (token === 'null') {
        return res.status(401).send('Unauthorized request')
    }
    let payload = jwt.verify(token, 'secretKey')
    if(!payload) {
        return res.status(401).send('Unauthorized request')
    }
    req.userId = payload.subject
    next()
 }

 router.post('/create' ,(req,res) => {
    res.send('user create route');
    let userData = req.body
     console.log(userData)
    let user = new User(userData)
    user.save((error, data) => {
        if(error) {
            console.log(error)
        } else {
            console.log(data, 'data after complete')
            // res.status(200).send({data})
        }
    })
})

router.post('/login', (req,res) => {
    let userData = req.body;

    User.findOne({ email: req.body.email}, (err, user) => {
        if(err) {
            console.log(err);
        } else {
            if(!user) {
                res.status(401).send('Invalid email')
            } else {
                if(user.password !== userData.password) {
                    res.status(401).send('Invalid Password')
                } else {
                    let payload = { subject: user._id}
                    let token = jwt.sign(payload, 'secretKey')
                    res.status(200).send({token})
                }
            }
        }
    })
})

router.get('/getUserDetail', verifyToken, (req, res) => {
    console.log(req.userId, 'req userId')
    User.findOne({ _id: req.userId }, (err, user) => {
        if (user) {
            console.log(user)
            res.send(user)
        } else {
            res.send(err)
        }
    })
})


module.exports = router;