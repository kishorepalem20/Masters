package com.example.hackonload.ad.app;

public class Api {

    public static final String KEY_USER_ID = "user_id";

    public static final String KEY_POS_X = "pos_x";
    public static final String KEY_POS_Y = "pos_y";
    public static final String KEY_POS_Z = "pos_z";
    public static final String KEY_DIRECTION = "direction";
    public static final String KEY_LATITUDE = "latitude";
    public static final String KEY_LONGITUDE = "longitude";
    public static final String KEY_MESSAGE = "message";



}
