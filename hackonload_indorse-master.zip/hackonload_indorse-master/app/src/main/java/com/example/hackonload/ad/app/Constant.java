package com.example.hackonload.ad.app;

public class Constant {
    public static final String EXTRA_POS_X = "pos_x";
    public static final String EXTRA_POS_Y = "pos_y";
    public static final String EXTRA_POS_Z = "pos_z";
    public static final String EXTRA_DIRECITON = "direction";

    public static final String VALUE_FRONT = "front";
    public static final String VALUE_BACK = "back";
}
